/// Description: A Human is the most common race in almost every fantasy setting.
///				 Its statistics are fairly normal.
///
/// Authors: Martin Pettersson, Christoffer Wiss
///	Version: 2013-12-09

#include "Human.h"
#include <iostream>
using std::cout;
using std::cin;
using std::cerr;
using std::endl;

namespace GameLogic
{
	// Destructor
	Human::~Human()
	{
		//TODO: Free Human related allocated memory here
	}
}